import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { parseJwt } from "../Actions/jwtutils"; // Ensure this utility is correctly implemented

const ProfileCard = () => {
    const [user, setUser] = useState(null);
    const token = localStorage.getItem("token");
    const tokenData = parseJwt(token);

    useEffect(() => {
        const fetchUserData = async () => {
            try {
                const response = await axios.get(`http://localhost:8080/User/retrieve/${tokenData.id}`, {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });
                setUser(response.data);
            } catch (error) {
                console.error("Error fetching user data:", error);
            }
        };

        fetchUserData();
    }, [token, tokenData.id]);

    if (!user) {
        return <div>Loading...</div>; // You can customize this loading state
    }

    return (
        <div className="container mt-5">
            <div className="card shadow-lg border-0">
                <div className="card-body">
                    <h5 className="card-title text-center mb-4">User Profile</h5>
                    <p className="card-text" style={{ color: 'black' }}><strong>ID:</strong> {user.id}</p>
                    <p className="card-text" style={{ color: 'black' }}><strong>Username:</strong> {user.username}</p>
                    <p className="card-text" style={{ color: 'black' }}><strong>Email:</strong> {user.email}</p>
                    <p className="card-text" style={{ color: 'black' }}><strong>Address:</strong> {user.address}</p>
                    <p className="card-text" style={{ color: 'black' }}><strong>Phone Number:</strong> {user.phoneno}</p>
                    <p className="card-text" style={{ color: 'black' }}><strong>Role:</strong> {user.role}</p>

                </div>
            </div>
        </div>
    );
};
export default ProfileCard;
