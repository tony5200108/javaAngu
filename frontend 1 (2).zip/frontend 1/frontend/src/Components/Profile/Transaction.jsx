import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './transaction.css';
import { parseJwt } from '../Actions/jwtutils';

const Transaction = () => {
    const [orders, setOrders] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    // Get the userId from token
    const token = localStorage.getItem("token");
    const tokenData = parseJwt(token);
    const userId = tokenData.id;

    useEffect(() => {
        const fetchOrders = async () => {
            try {
                const response = await axios.get(`http://localhost:8080/Payment/user/transactions/${userId}`, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    }
                });
                setOrders(response.data);
            } catch (err) {
                setError(err.response ? err.response.data : "An error occurred");
            } finally {
                setLoading(false);
            }
        };

        fetchOrders();
    }, [userId, token]);

    if (loading) {
        return <p>Loading...</p>;
    }

    if (error) {
        return <p>Error: {error}</p>;
    }

    return (
        <div className="transaction-component">
            <h2>Your Transactions</h2>
            {orders.length === 0 ? (
                <p>No transactions found.</p>
            ) : (
                <table>
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>User ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Razorpay Order ID</th>
                        </tr>
                    </thead>
                    <tbody>
                        {orders.map(order => (
                            <tr key={order.orderId}>
                                <td>{order.orderId}</td>
                                <td>{order.userid}</td>
                                <td>{order.name}</td>
                                <td>{order.email}</td>
                                <td>₹{order.amount}</td>
                                <td>{order.orderStatus}</td>
                                <td>{order.razorpayOrderId}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
        </div>
    );
};

export default Transaction;
