import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { parseJwt } from '../Actions/jwtutils'; // Importing the utility function

const MyBookings = () => {
    const [bookings, setBookings] = useState([]);
    const [error, setError] = useState(null);
    const [noBookingsMessage, setNoBookingsMessage] = useState(null);
    const token = localStorage.getItem("token");
    const tokenData = parseJwt(token); // Parse the JWT token to get user data
    const userId = tokenData.id; // Safely access user ID

    useEffect(() => {
        const fetchUserBookings = async () => {
            try {
                const response = await axios.get(`http://localhost:8080/Bookings/user/getUserTickets/${userId}`, {
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                });

                // Assuming the server sends a message when there are no bookings
                if (response.data && Array.isArray(response.data) && response.data.length > 0) {
                    setBookings(response.data);
                    setNoBookingsMessage(null); // Clear message if bookings exist
                } else {
                    setNoBookingsMessage('No bookings available for this user.');
                    setBookings([]); // Clear previous bookings
                }
            } catch (error) {
                console.error('Error fetching bookings:', error);
                if (error.response) {
                    if (error.response.status === 404) {
                        setNoBookingsMessage(error.response.data || 'No bookings found.');
                    } else {
                        setError(error.response.data.message || 'Failed to fetch bookings.');
                    }
                } else {
                    setError('Failed to fetch bookings.');
                }
            }
        };

        if (userId) {
            fetchUserBookings();
        } else {
            setError('User ID not found. Please log in again.');
        }
    }, [userId]);

    const handleCancelBooking = async (ticketId) => {
        const confirmCancel = window.confirm(`Are you sure you want to Cancel the ticket ${ticketId}?`);
        if (!confirmCancel) return;
        try {
            await axios.put(`http://localhost:8080/Bookings/user/cancel/${ticketId}`, {}, {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            setBookings(prevBookings =>
                prevBookings.map(booking =>
                    booking.ticketId === ticketId
                        ? { ...booking, status: 'Cancelled' } // Update status
                        : booking
                )
            );
            alert(`Booking ${ticketId} canceled successfully.`);
        } catch (error) {
            console.error('Error canceling booking:', error);
            alert('Failed to cancel booking. Please try again.');
        }
    };

    return (
        <div style={styles.container}>
            <h2>My Bookings</h2>
            {error && <p style={styles.error}>{error}</p>}
            {noBookingsMessage && <p style={styles.noBookings}>{noBookingsMessage}</p>}
            {bookings.length > 0 && (
                <table style={styles.table}>
                    <thead>
                        <tr>
                            <th>Ticket ID</th>
                            <th>User ID</th>
                            <th>Train ID</th>
                            <th>No. of Seats</th>
                            <th>Fare Amount</th>
                            <th>Booking Time</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {bookings.map((booking) => (
                            <tr key={booking.ticketId}>
                                <td>{booking.ticketId}</td>
                                <td>{booking.userId}</td>
                                <td>{booking.trainId}</td>
                                <td>{booking.noOfSeats}</td>
                                <td>{booking.fareamount}</td>
                                <td>{new Date(booking.bookingTime).toLocaleString()}</td>
                                <td>{booking.status}</td>
                                <td>
                                    {booking.status === 'Cancelled' ? (
                                        'No Action' // Display "No Action" if the status is Cancelled
                                    ) : (
                                        <button style={styles.button} onClick={() => handleCancelBooking(booking.ticketId)}>Cancel</button>
                                    )}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
        </div>
    );
};

const styles = {
    container: {
        padding: '20px',
        backgroundColor: '#f9f9f9',
        borderRadius: '8px',
        boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
    },
    error: {
        color: 'red',
    },
    noBookings: {
        color: 'orange',
    },
    table: {
        width: '100%',
        borderCollapse: 'collapse',
        marginTop: '20px',
    },
    button: {
        backgroundColor: '#FF6347', // Tomato color
        color: 'white',
        border: 'none',
        borderRadius: '4px',
        padding: '8px 12px',
        cursor: 'pointer',
        transition: 'background-color 0.3s',
    },
};

export default MyBookings;
