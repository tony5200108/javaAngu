import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import axios from 'axios';
import './BookingCard.css'
import { parseJwt } from '../Actions/jwtutils';

const BookingCard = () => {
    const location = useLocation();
    const train = location.state?.train; // Retrieve the train data
    const token = localStorage.getItem("token");
    const tokenData = parseJwt(token);
    const userId = tokenData.id;
    const userEmail = tokenData.email; // Get email from token
    const [numberOfSeats, setNumberOfSeats] = useState(1); // Default to 1 seat

    useEffect(() => {
        const script = document.createElement('script');
        script.src = 'https://checkout.razorpay.com/v1/checkout.js';
        script.async = true;
        document.body.appendChild(script);

        return () => {
            document.body.removeChild(script);
        };
    }, []);

    const handlePayment = async () => {

        if (numberOfSeats < 1 || numberOfSeats > 4) {
            alert("No of seats between 1 to 4");
            return;
        }

        try {
            const orderData = {
                name: tokenData.sub,
                email: userEmail,
                amount: train.fare * numberOfSeats,
                userid: userId
            };

            // Create the order on the backend
            const response = await axios.post('http://localhost:8080/Payment/user/createOrder', orderData, {
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });

            const order = response.data;
            console.log(order);

            const options = {
                key: "rzp_test_GGqgmFBLIg33LX",
                amount: order.amount * 100,
                currency: "INR",
                name: "Train Booking",
                description: `Booking for ${train.trainNumber}`,
                order_id: order.razorpayOrderId,
                prefill: {
                    name: order.name,
                    email: order.email,
                    userid: order.userid,
                },
                theme: {
                    color: "#339900",
                },
                handler: async function (paymentResponse) {
                    try {
                        // Send payment response to the backend
                        const callbackResponse = await axios.post('http://localhost:8080/Payment/user/paymentCallback', paymentResponse, {
                            headers: {
                                Authorization: `Bearer ${token}`,
                                'Content-Type': 'application/json'
                            }
                        });

                        const result = callbackResponse.data;
                        console.log("Payment callback response:", result);
                        console.log(result.status)

                        if (result === "Payment Successful") {
                            // Call the booking API
                            const bookingData = {
                                userId: userId,
                                trainId: train.trainNumber, // Assuming train.trainNumber is the train ID
                                noOfSeats: numberOfSeats
                            };

                            const bookingResponse = await axios.post('http://localhost:8080/Bookings/user/bookTicket', bookingData, {
                                headers: {
                                    Authorization: `Bearer ${token}`,
                                    'Content-Type': 'application/json'
                                }
                            });

                            console.log("Booking response:", bookingResponse);

                            if (bookingResponse.status === 200) {
                                alert("Ticket booked successfully!");
                            } else {
                                alert("Failed to book ticket.");
                            }
                        } else {
                            alert("Payment processing failed.");
                        }
                    } catch (error) {
                        console.error("Error during payment callback: ", error);
                    }
                },
                modal: {
                    ondismiss: function () {
                        console.log("Payment dismissed");
                    }
                }
            };

            const rzp1 = new window.Razorpay(options);
            rzp1.open();
        } catch (error) {
            console.error("Error during payment process: ", error);
        }
    };



    if (!train) {
        return <p>No train selected.</p>; // Handle the case where no train data is passed
    }

    return (
        <div className="booking-card">
            <h2 className="booking-title">Booking Details</h2>
            <div className="booking-info">
                <p><strong>Train Number:</strong> {train.trainNumber}</p>
                <p><strong>Source:</strong> {train.source}</p>
                <p><strong>Destination:</strong> {train.destination}</p>
                <p><strong>Fare:</strong> ₹{train.fare}</p>
                <p><strong>User ID:</strong> {userId}</p>
            </div>
            <div className="seats-container">
                <input
                    type="number"
                    placeholder="Number of Seats"
                    value={numberOfSeats}
                    onChange={(e) => setNumberOfSeats(e.target.value)}
                    min="1"
                    className="seats-input"
                />
                <button onClick={handlePayment} className="pay-button">Pay</button>
            </div>
        </div>
    );

};

export default BookingCard;
