import React from "react";
import home from '../Images/home.jpg';

const Background = () => {
    const styles = {
        backgroundImage: `url(${home})`,
        backgroundSize: 'cover',
        backgroundRepeat: 'no-repeat',
        backgroundPosition: 'center',
        height: '100vh',
        width: '100%',
        position: 'fixed', // Use fixed to prevent scrolling
        top: 0,
        left: 0,
        zIndex: 0, // Lower z-index than form content
        overflow: 'hidden', // Prevent overflow
    };

    return <div style={styles}></div>;
};

export default Background;
