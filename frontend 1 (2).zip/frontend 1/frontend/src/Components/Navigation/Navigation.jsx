import React from "react";
import "./Nav.css";
import Logo from '../Logo/train3.ico'
import { Link } from "react-router-dom";

const Navigation = () => {
    return (
        <div>
            <nav>
                <div className="logo">
                    <img src={Logo} alt="Logo" style={{ height: '40px', width: '40px' }} />
                    <h5 style={{ margin: 0, marginLeft: '10px', color: 'white' }}>Railway Reservation System</h5>
                </div>
                <ul>
                    <Link to="/"><li>Home</li></Link>
                    <Link to="/register"><li>Register</li></Link>
                    <Link to="/login"><li>Login</li></Link>
                </ul>
            </nav>
        </div>
    )
}

export default Navigation;