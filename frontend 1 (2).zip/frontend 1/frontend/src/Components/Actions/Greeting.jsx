import React from "react";
import { parseJwt } from "../Actions/jwtutils";

const Greeting = () => {
    const token = localStorage.getItem("token");
    const tokenData = parseJwt(token);

    const getGreeting = () => {
        const hours = new Date().getHours();
        if (hours < 12) {
            return "Good Morning";
        } else if (hours < 18) {
            return "Good Afternoon";
        } else {
            return "Good Evening";
        }
    };

    return (
        <div>
            <h1>
                {getGreeting()}, {tokenData.sub.toUpperCase()}! Welcome to the Ticket Booking System
            </h1>
        </div>
    );
};



export default Greeting;
