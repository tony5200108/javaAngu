export const parseJwt = (token) => {
    if (!token) return null;

    const base64Url = token.split('.')[1]; // Get the payload part
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/'); // Replace URL-safe characters
    const jsonPayload = decodeURIComponent(escape(window.atob(base64))); // Decode Base64

    return JSON.parse(jsonPayload); // Parse JSON
};
// {
//     "role": "USER",
//     "id": 2,
//     "email": "dileep@gmail.com",
//     "sub": "dileep",
//     "iat": 1730279120,
//     "exp": 1730280920
//   }