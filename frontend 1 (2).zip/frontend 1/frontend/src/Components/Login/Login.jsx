import React, { useState } from "react";
import './register.css'; // Import the CSS file
import axios from 'axios';
import { Link } from "react-router-dom";
import { useNavigate } from 'react-router-dom';

const Login = () => {

    const [user, setUser] = useState("");
    const [password, setPass] = useState("");
    const [message, setMessage] = useState("");
    const navigate = useNavigate(); // Hook to navigate programmatically

    const handleEvent = async (e) => {
        e.preventDefault();
        if (user === '' || password === '') {
            setMessage("Input cannot be empty");
            return;
        }
        // Create the payload
        const authRequest = {
            username: user,
            password: password,
        };

        try {
            // Send the POST request to the backend
            const response = await axios.post("http://localhost:8080/User/login", authRequest);
            localStorage.setItem("token", response.data); // Store jwt token in local storage
            // Handle the successful response
            setMessage("Login successful!");
            navigate('/dashboard');
        } catch (error) {
            // Handle errors (e.g., invalid credentials)
            if (error.response) {
                setMessage("Error: " + error.response.data);
            } else {
                setMessage("Error: Unable to reach the server");
            }
        }
        setUser('');
        setPass('');
    };

    return (
        <div className="login-container">
            <form onSubmit={handleEvent}>
                <h2 className="login-title">login</h2>

                <div className="input-group">
                    <label className="login-label">Username:</label>
                    <input type="text" className="login-input" value={user} onChange={(e) => setUser(e.target.value)} />
                </div>


                <div className="input-group">
                    <label className="login-label">Password:</label>
                    <input type="password" className="login-input" value={password} onChange={(e) => setPass(e.target.value)} />
                </div>


                <input type="submit" value="Login" className="login-button" />
            </form>
            <h6 style={{ textAlign: 'center', marginTop: '10px', color: 'white' }}>Don't have account? <Link to='/register'>Sign up</Link></h6>
            {message && <p>{message}</p>}
        </div>
    );
};

export default Login;
