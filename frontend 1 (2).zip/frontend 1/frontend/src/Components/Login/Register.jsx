import React, { useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import './register.css'; // Import the CSS file

function Register() {
    const [user, setUser] = useState("");
    const [password, setPass] = useState("");
    const [mail, setMail] = useState("");
    const [message, setMessage] = useState("");
    const [address, setAddress] = useState("");
    const [phone, setPhone] = useState("");

    const handleEvent = async (e) => {
        e.preventDefault();

        if (user === '' || password === '' || mail === '' || phone === '') {
            setMessage("Input cannot be empty");
            return;
        }

        // Validate phone number
        const phonePattern = /^\d{10}$/;
        if (!phonePattern.test(phone)) {
            alert("Phone number must be exactly 10 digits");
            return;
        }
        const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{5,8}$/;
        if (!passwordPattern.test(password)) {
            alert("Password Doesn't Meet Standards");
            return;
        }
        const lowercaseEmail = mail.toLowerCase();
        // Create the payload
        const authRequest = {
            username: user,
            email: lowercaseEmail,
            password: password,
            address: address,
            phoneno: phone,
        };

        try {
            // Send the POST request to the backend
            await axios.post("http://localhost:8080/User/register", authRequest);
            // Handle the successful response
            setMessage("User added successfully!");
        } catch (error) {
            // Handle errors (e.g., invalid credentials)
            if (error.response) {
                setMessage("Error: " + error.response.data);
            } else {
                setMessage("Error: Unable to reach the server");
            }
        }

        // Reset form fields
        setUser('');
        setMail('');
        setPass('');
        setAddress('');
        setPhone('');
    };

    return (
        <div className="login-container">
            <form onSubmit={handleEvent}>
                <h2 className="login-title">Register</h2>

                <div className="input-group">
                    <label className="login-label">UserName:</label>
                    <input type="text" className="login-input" value={user} onChange={(e) => setUser(e.target.value)} />
                </div>

                <div className="input-group">
                    <label className="login-label">Email:</label>
                    <input type="email" className="login-input" value={mail} onChange={(e) => setMail(e.target.value)} />
                </div>

                <div className="input-group">
                    <label className="login-label">Password:</label>
                    <input type="password" className="login-input" value={password} onChange={(e) => setPass(e.target.value)} />
                </div>

                <div className="input-group">
                    <label className="login-label">Address:</label>
                    <input type="text" className="login-input" value={address} onChange={(e) => setAddress(e.target.value)} />
                </div>

                <div className="input-group">
                    <label className="login-label">Phone Number:</label>
                    <input type="tel" className="login-input" value={phone} onChange={(e) => setPhone(e.target.value)} />
                </div>

                <input type="submit" value="Register" className="login-button" />
            </form>
            <h6 style={{ textAlign: 'center', marginTop: '10px', color: 'white' }}>Already have account? <Link to='/login'>Sign in</Link></h6>
            {message && <p>{message}</p>}
        </div>
    );
}

export default Register;
