import React, { useEffect, useState } from 'react';
import axios from 'axios';
import BookingCard from '../Profile/BookingCard';
import './FindAllTrains.css';
import { Link } from 'react-router-dom';

const FindAllTrains = () => {
    const [trains, setTrains] = useState([]);
    const [error, setError] = useState(null);
    const [selectedTrain, setSelectedTrain] = useState(null);
    const token = localStorage.getItem("token");
    const userId = JSON.parse(atob(token.split('.')[1])).id; // Get user ID from JWT

    useEffect(() => {
        const fetchAllTrains = async () => {
            try {
                const response = await axios.get('http://localhost:8080/Trains/user/getAll', {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });
                setTrains(response.data);
            } catch (error) {
                console.error('Error fetching all trains:', error);
                setError('Failed to fetch all trains.');
            }
        };

        fetchAllTrains();
    }, [token]);


    const handleCloseCard = () => {
        setSelectedTrain(null);
    };

    const handleBook = (bookingData) => {
        console.log("Booking data:", bookingData);
        // Here you would handle the payment integration
        // After successful payment, book the ticket
        handleCloseCard();
    };

    return (
        <div>
            <h2>All Trains</h2>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            <table className="train-table">
                <thead>
                    <tr>
                        <th>Train Number</th>
                        <th>Source</th>
                        <th>Destination</th>
                        <th>Departure Time</th>
                        <th>Arrival Time</th>
                        <th>Fare</th>
                        <th>Total Seats</th>
                        <th>Booking</th>
                    </tr>
                </thead>
                <tbody>
                    {trains.map((train) => (
                        <tr key={train.trainNumber}>
                            <td>{train.trainNumber}</td>
                            <td>{train.source}</td>
                            <td>{train.destination}</td>
                            <td>{train.departureTime}</td>
                            <td>{train.arrivalTime}</td>
                            <td>{train.fare}</td>
                            <td>{train.totalSeats}</td>
                            <td>
                                <Link
                                    to="/dashboard/booking"
                                    state={{ train }} // Pass the train data here
                                >
                                    <button className="booking-button">Book</button>
                                </Link>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
            {selectedTrain && (
                <BookingCard
                    train={selectedTrain}
                    userId={userId}
                    onClose={handleCloseCard}
                    onBook={handleBook}
                />
            )}
        </div>
    );
};

export default FindAllTrains;
