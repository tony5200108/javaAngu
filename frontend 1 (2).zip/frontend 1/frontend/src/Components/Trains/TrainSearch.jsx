import React, { useState } from 'react';
import TrainResults from './TrainResults'; // Import your results component

const TrainSearch = () => {
    const [source, setSource] = useState('');
    const [destination, setDestination] = useState('');
    const [showResults, setShowResults] = useState(false); // State to control results display

    const handleSearch = () => {
        if (source && destination) { // Check if both inputs are filled
            setShowResults(true);
            setSource('');
            setDestination('');
        } else {
            alert("Please enter both source and destination."); // Alert if inputs are missing
        }
    };

    return (
        <div style={styles.container}>
            <h2>Search for Trains</h2>
            <div style={styles.inputContainer}>
                <input
                    style={styles.input}
                    type="text"
                    placeholder="Source"
                    value={source}
                    onChange={(e) => setSource(e.target.value)}
                />
                <input
                    style={styles.input}
                    type="text"
                    placeholder="Destination"
                    value={destination}
                    onChange={(e) => setDestination(e.target.value)}
                />
                <button style={styles.button} onClick={handleSearch}>Search</button>
            </div>
            {showResults && ( // Only show results if search has been made
                <TrainResults source={source} destination={destination} />
            )}
        </div>
    );
};

const styles = {
    container: {
        padding: '20px',
        backgroundColor: '#f9f9f9',
        borderRadius: '8px',
        boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
    },
    inputContainer: {
        display: 'flex',
        gap: '10px',
        marginBottom: '20px',
    },
    input: {
        flex: 1,
        padding: '10px',
        border: '1px solid #ccc',
        borderRadius: '4px',
    },
    button: {
        backgroundColor: '#007BFF',
        color: 'white',
        border: 'none',
        borderRadius: '4px',
        padding: '10px 15px',
        cursor: 'pointer',
        transition: 'background-color 0.3s',
    },
};

export default TrainSearch;
