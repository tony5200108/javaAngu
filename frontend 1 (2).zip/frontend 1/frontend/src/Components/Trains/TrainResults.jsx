import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import './FindAllTrains.css';

const TrainResults = ({ source, destination }) => {
    const [trains, setTrains] = useState([]);
    const [error, setError] = useState(null);
    const token = localStorage.getItem("token");

    useEffect(() => {
        const searchByStation = async () => {
            setError(null); // Clear previous error
            try {
                const response = await axios.get(`http://localhost:8080/Trains/user/searchByStation`, {
                    headers: {
                        Authorization: `Bearer ${token}`
                    },
                    params: {
                        source,
                        destination
                    }
                });
                setTrains(response.data);
            } catch (error) {
                console.error('Error searching by station:', error);
                setError('No Train Found');
            }
        };

        if (source && destination) {
            searchByStation();
        }
    }, [source, destination, token]);

    return (
        <div>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            <h2>Train List</h2>
            <table className='train-table'>
                <thead>
                    <tr>
                        <th>Train Number</th>
                        <th>Source</th>
                        <th>Destination</th>
                        <th>Departure Time</th>
                        <th>Arrival Time</th>
                        <th>Fare</th>
                        <th>Total Seats</th>
                        <th>Booking</th>
                    </tr>
                </thead>
                <tbody>
                    {trains.map((train) => (
                        <tr key={train.trainNumber}>
                            <td>{train.trainNumber}</td>
                            <td>{train.source}</td>
                            <td>{train.destination}</td>
                            <td>{train.departureTime}</td>
                            <td>{train.arrivalTime}</td>
                            <td>{train.fare}</td>
                            <td>{train.totalSeats}</td>
                            <td>
                                <Link
                                    to="/dashboard/booking"
                                    state={{ train }} // Pass the train data
                                >
                                    <button className='booking-button'>Book</button>
                                </Link>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default TrainResults;
