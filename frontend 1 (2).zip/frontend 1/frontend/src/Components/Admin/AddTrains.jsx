import React, { useState } from 'react';
import axios from 'axios';
import './AddTrains.css'

const AddTrain = () => {
    const [train, setTrain] = useState({
        trainNumber: '',
        source: '',
        destination: '',
        departureTime: '',
        arrivalTime: '',
        fare: '', // Keep as a string for input purposes
        totalSeats: '', // Keep as a string for input purposes
    });

    const token = localStorage.getItem("token");

    const [error, setError] = useState('');

    const handleChange = (e) => {
        const { name, value } = e.target;
        setTrain({ ...train, [name]: value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        // Validate train number (must be 5 digits)
        if (!/^\d{5}$/.test(train.trainNumber)) {
            setError('Train number must be exactly 5 digits.');
            return;
        }

        // Validate fare (must be a number)
        if (isNaN(train.fare) || train.fare <= 0) {
            setError('Fare must be a positive number.');
            return;
        }

        // Validate total seats (must be a whole number)
        if (isNaN(train.totalSeats) || train.totalSeats <= 0) {
            setError('Total seats must be a positive whole number.');
            return;
        }

        setError(''); // Clear any previous errors


        // Prepare data to send
        const trainData = {
            trainNumber: train.trainNumber,
            source: train.source,
            destination: train.destination,
            departureTime: train.departureTime,
            arrivalTime: train.arrivalTime,
            fare: parseFloat(train.fare), // Convert to float
            totalSeats: parseInt(train.totalSeats), // Convert to integer
        };

        try {
            const response = await axios.post('http://localhost:8080/Trains/addDetails', trainData, {
                headers: {
                    Authorization: `Bearer ${token}`, // Add your token if required
                    'Content-Type': 'application/json' // Ensure the correct content type
                }
            });
            alert('Train added successfully: ' + response.data.trainNumber);

            // Clear the form after successful submission
            setTrain({
                trainNumber: '',
                source: '',
                destination: '',
                departureTime: '',
                arrivalTime: '',
                fare: '',
                totalSeats: '',
            });
        } catch (error) {
            console.error('Error adding train:', error);
            alert('Failed to add train. Please check the details and try again.');
        }
    };

    return (
        <div className="add-train-container">
            <h2>Add Train</h2>
            {error && <div className="error-message">{error}</div>}
            <form onSubmit={handleSubmit}>
                <table>
                    <tbody>
                        <tr>
                            <td><label>Train Number:</label></td>
                            <td><input type="text" name="trainNumber" value={train.trainNumber} onChange={handleChange} required /></td>
                        </tr>
                        <tr>
                            <td><label>Source:</label></td>
                            <td><input type="text" name="source" value={train.source} onChange={handleChange} required /></td>
                        </tr>
                        <tr>
                            <td><label>Destination:</label></td>
                            <td><input type="text" name="destination" value={train.destination} onChange={handleChange} required /></td>
                        </tr>
                        <tr>
                            <td><label>Departure Time:</label></td>
                            <td><input type="time" name="departureTime" value={train.departureTime} onChange={handleChange} required /></td>
                        </tr>
                        <tr>
                            <td><label>Arrival Time:</label></td>
                            <td><input type="time" name="arrivalTime" value={train.arrivalTime} onChange={handleChange} required /></td>
                        </tr>
                        <tr>
                            <td><label>Fare:</label></td>
                            <td><input type="number" name="fare" value={train.fare} onChange={handleChange} required /></td>
                        </tr>
                        <tr>
                            <td><label>Total Seats:</label></td>
                            <td><input type="number" name="totalSeats" value={train.totalSeats} onChange={handleChange} required /></td>
                        </tr>
                    </tbody>
                </table>
                <button type="submit">Add Train</button>
            </form>
        </div>
    );
};

export default AddTrain;
