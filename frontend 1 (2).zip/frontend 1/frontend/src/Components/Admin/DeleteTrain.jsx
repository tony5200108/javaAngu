import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './DeleteTrains.css';

const DeleteTrains = () => {
    const [trains, setTrains] = useState([]);
    const [error, setError] = useState(null);
    const token = localStorage.getItem("token");

    useEffect(() => {
        const fetchAllTrains = async () => {
            try {
                const response = await axios.get('http://localhost:8080/Trains/user/getAll', {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });
                setTrains(response.data);
            } catch (error) {
                console.error('Error fetching all trains:', error);
                setError('Failed to fetch all trains.');
            }
        };

        fetchAllTrains();
    }, [token]);

    const handleDelete = async (trainNumber) => {
        const confirmDelete = window.confirm(`Are you sure you want to delete train number ${trainNumber}?`);
        if (!confirmDelete) return;

        try {
            await axios.delete(`http://localhost:8080/Trains/delete/${trainNumber}`, {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            setTrains(trains.filter(train => train.trainNumber !== trainNumber)); // Remove the deleted train from the state
            alert('Train deleted successfully.');
        } catch (error) {
            console.error('Error deleting train:', error);
            setError('Failed to delete train.');
        }
    };

    return (
        <div>
            <h2>All Trains</h2>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            <table className="train-table">
                <thead>
                    <tr>
                        <th>Train Number</th>
                        <th>Source</th>
                        <th>Destination</th>
                        <th>Departure Time</th>
                        <th>Arrival Time</th>
                        <th>Fare</th>
                        <th>Total Seats</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {trains.map((train) => (
                        <tr key={train.trainNumber}>
                            <td>{train.trainNumber}</td>
                            <td>{train.source}</td>
                            <td>{train.destination}</td>
                            <td>{train.departureTime}</td>
                            <td>{train.arrivalTime}</td>
                            <td>{train.fare}</td>
                            <td>{train.totalSeats}</td>
                            <td>
                                <button className="delete-button" onClick={() => handleDelete(train.trainNumber)}>Delete</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default DeleteTrains;
