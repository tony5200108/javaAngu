import React from "react";
import { Link, useNavigate } from "react-router-dom";
import Greeting from "../Actions/Greeting";
import Logo from '../Logo/train3.ico';
import './NavBar.css'; // Import the CSS file
import { parseJwt } from "../Actions/jwtutils";

const NavBar = () => {
    const navigate = useNavigate();
    const token = localStorage.getItem("token");
    const tokenData = parseJwt(token);

    const handleLogout = () => {
        localStorage.removeItem("token");
        navigate("/login");
    };

    return (
        <div style={styles.container}>
            <nav className="navbar navbar-expand-lg" style={styles.navbar}>
                <div className="logo">
                    <img src={Logo} alt="Logo" style={{ height: '40px', width: '40px' }} />
                    <h5 style={{ margin: 0, marginLeft: '10px', color: 'white' }}>Railway Reservation System</h5>
                </div>
                <div className="container-fluid">
                    <button
                        className="navbar-toggler"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#navbarNavDropdown"
                        aria-controls="navbarNavDropdown"
                        aria-expanded="false"
                        aria-label="Toggle navigation"
                    >
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarNavDropdown">
                        <ul className="navbar-nav ms-auto">
                            {tokenData && tokenData.role === "Admin" && (
                                <li className="nav-item dropdown me-3">
                                    <a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" style={{ color: 'white' }}>
                                        Admin Options
                                    </a>
                                    <ul className="dropdown-menu dropdown-menu-end">
                                        <li>
                                            <Link className="dropdown-item" to="/dashboard/Addtrains">Add Trains</Link>
                                        </li>
                                        <li>
                                            <Link className="dropdown-item" to="/dashboard/delete">Delete Trains</Link>
                                        </li>
                                    </ul>
                                </li>
                            )}
                            <li className="nav-item dropdown me-3">
                                <a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" style={{ color: 'white' }}>
                                    Find Trains
                                </a>
                                <ul className="dropdown-menu dropdown-menu-end">
                                    <li>
                                        <Link className="dropdown-item" to="/dashboard/find-all-trains">Find All Trains</Link>
                                    </li>
                                    <li>
                                        <Link className="dropdown-item" to="/dashboard/search-by-station">Search by Station</Link>
                                    </li>
                                </ul>
                            </li>
                            <li className="nav-item dropdown">
                                <a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" style={{ color: 'white' }}>
                                    Profile
                                </a>
                                <ul className="dropdown-menu dropdown-menu-end">
                                    <li>
                                        <Link className="dropdown-item" to="/dashboard/profile">View Profile</Link>
                                    </li>
                                    <li>
                                        <Link className="dropdown-item" to="/dashboard/Mybookings">My Bookings</Link>
                                    </li>
                                    <li>
                                        <Link className="dropdown-item" to="/dashboard/transactions">My Transactions</Link>
                                    </li>
                                    <li>
                                        <button className="button" onClick={handleLogout}>
                                            Logout
                                        </button>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <div style={styles.greetingContainer}>
                <Greeting />
            </div>
        </div>
    );
};

const styles = {
    container: {
        display: 'flex',
        flexDirection: 'column',
        height: '25vh',
    },
    navbar: {
        height: '15vh',
        display: 'flex',
        alignItems: 'center', // Center items vertically
        backgroundColor: '#7d7d82', // Set navbar background color
        padding: '0 20px',
    },
    greetingContainer: {
        height: '10vh',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#f0f0f0',
    },
};

export default NavBar;
