import React from "react";
import { Outlet } from "react-router-dom";
import Navigation from '../Components/Navigation/Navigation';

const Home = () => {
    return (
        <div className="app" style={{ backgroundColor: '#e0f7fa' }}>
            <Navigation />
            <div style={{ position: 'relative', zIndex: 2, display: 'flex', justifyContent: 'center', alignItems: 'flex-start', minHeight: '100vh' }}>
                <Outlet /> {/* This will render the matched child routes */}
            </div>
        </div>
    );
};

export default Home;
