import React from "react";
import NavBar from "../Components/Dashboard/Navbar";
import { Outlet } from "react-router-dom";


const DashPage = () => {
    return (
        <div className="app">
            <NavBar />
            <Outlet />
        </div>
    );
};

export default DashPage;
