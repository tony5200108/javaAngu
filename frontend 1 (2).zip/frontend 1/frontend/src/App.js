import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Home from './Pages/Home'; // Ensure you import Home correctly
import Register from './Components/Login/Register';
import Login from './Components/Login/Login';
import DashboardPage from './Pages/DashboardPage';
import Profile from './Components/Profile/Profile';
import TrainSearch from './Components/Trains/TrainSearch';
import FindAllTrains from './Components/Trains/FindAllTrains';
import MyBookings from './Components/Profile/MyBookings';
import BookingCard from './Components/Profile/BookingCard';
import Transaction from './Components/Profile/Transaction';
import AddTrain from './Components/Admin/AddTrains';
import DeleteTrain from './Components/Admin/DeleteTrain';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<Home />}>
          <Route path='register' element={<Register />} />
          <Route path='login' element={<Login />} />
        </Route>
        <Route path='/dashboard' element={<DashboardPage />}>
          <Route path='profile' element={<Profile />} />
          <Route path='search-by-station' element={<TrainSearch />}></Route>
          <Route path='find-all-trains' element={<FindAllTrains />} />
          <Route path='Mybookings' element={<MyBookings />}></Route>
          <Route path='booking' element={<BookingCard />}></Route>
          <Route path='transactions' element={<Transaction />}></Route>
          <Route path='Addtrains' element={<AddTrain />}></Route>
          <Route path='delete' element={<DeleteTrain />}></Route>
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
