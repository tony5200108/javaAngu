package com.example.exception;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
public class ResponseEntityExceptionHandler {
	
	@ExceptionHandler(UserAlreadyPresentException.class)
	public ResponseEntity<Object> userAlreadyPresentException(UserAlreadyPresentException ex) {
		
		return ResponseEntity.status(HttpStatus.CONFLICT).body(ex.getMessage());
		
	}
	
	@ExceptionHandler(UserNotFoundException.class)
	public ResponseEntity<Object> userNotPresentException(UserNotFoundException ex) {
		
		return ResponseEntity.status(HttpStatus.CONFLICT).body(ex.getMessage());
		
	}

}