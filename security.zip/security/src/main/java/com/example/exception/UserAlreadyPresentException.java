package com.example.exception;

public class UserAlreadyPresentException extends Exception {
	public UserAlreadyPresentException(String str) {
		super(str);
	}
}
