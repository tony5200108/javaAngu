package com.example.service;

import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.config.CustomUserDetailsService;
import com.example.dto.AuthRequest;
import com.example.exception.UserAlreadyPresentException;
import com.example.exception.UserNotFoundException;
import com.example.model.Users;
import com.example.repository.UserRepo;




@Service
public class UserServiceImpl implements UserService{
	
	
	
	//private Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);
	
	@Autowired
    private PasswordEncoder encoder;
	
	@Autowired
	UserRepo userRepository;
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private CustomUserDetailsService customUserDetailsService;

	
	@Autowired
	private JwtService jwtService;

	@Override
	public Users addUser(Users user) throws UserAlreadyPresentException
	{
		// TODO Auto-generated method stub
		List<Users> userList = userRepository.findAll();
		if(userList.isEmpty()) {
			  	//logger.info("Registering new user: {}", user.getUsername());
				user.setPassword(encoder.encode(user.getPassword()));
				Users u = userRepository.save(user);
				//logger.info("User registered successfully: {}", user.getUsername());
				return user;
		}
		else {
			String uname = user.getUsername();
			boolean flag = false;
			for(Users u: userList) {
				if(u.getUsername().equalsIgnoreCase(uname)) {
					flag = true;
				}
			}
			if(flag) {
				//logger.info("User already exists...");
				throw new UserAlreadyPresentException("Can't add user. Already exits.");
			}
			else {
				//logger.info("Registering new user: {}", user.getUsername());
				user.setId(generateUniqueUserId());
				user.setPassword(encoder.encode(user.getPassword()));
				Users u =userRepository.save(user);
				//logger.info("User registered successfully: {}", user.getUsername());
				return user;
			}
		}
	}
	
	private int generateUniqueUserId() {
	    Random random = new Random();
	    int ticketId;
	    do {
	        // Generate three random digits
	    	ticketId = random.nextInt(1000);
	        
	    } while (userRepository.existsById(ticketId)); // Check for uniqueness in the database
	    
	    return ticketId;
	}

	

	@Override
	public Users getUserById(int userId) throws UserNotFoundException {
		// TODO Auto-generated method stub
		return userRepository.findById(userId)
	            .orElseThrow(() -> new UserNotFoundException("Unable to find the User with ID: " + userId));
	}

	
	
	@Override
	public String login(AuthRequest loginUser) throws UserNotFoundException {
		//need to apply jwt
 	   String str = null;
 	   try {
	 	   Authentication authentication =  authenticationManager.authenticate(
	 			   new UsernamePasswordAuthenticationToken(
	                        loginUser.getUsername(),
	                        loginUser.getPassword()
	                ));
	 	   if(authentication.isAuthenticated()) {
	 		   Users u = userRepository.findByUsername(loginUser.getUsername());
	 		  //logger.info("User authenticated successfully: {}", u.getUsername());
	 		  str = jwtService.generateToken(u.getUsername(),u.getRole(),u.getId(),u.getEmail());
	 	   	   return str;
	 	   }else {
	 		  //logger.warn("Invalid credentials for user: {}", loginUser.getUsername());
	 		  throw new UserNotFoundException("Invalid user name or password(UserService)");
	 	   }
 	   }
 	   catch(BadCredentialsException e) {
 		  //logger.error("Invalid credentials: {}", loginUser.getUsername(), e);
 		   throw new UserNotFoundException("Invalid user name or password");
 	   }
	}

}
