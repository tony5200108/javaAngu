package com.example.service;

import java.util.List;

import com.example.dto.AuthRequest;
import com.example.exception.UserAlreadyPresentException;
import com.example.exception.UserNotFoundException;
import com.example.model.Users;


public interface UserService {
	public Users addUser(Users user) throws UserAlreadyPresentException;

	public Users getUserById(int userId) throws UserNotFoundException;
	
	public String login(AuthRequest loginUser) throws UserNotFoundException;
}

