package com.example.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.exception.BookingNotFoundException;
import com.example.exception.InvalidTicketCountException;
import com.example.exception.TrainNotFoundException;
import com.example.exception.UserNotFoundException;
import com.example.feign.PaymentServicefeignClient;
import com.example.feign.TrainServiceFeignClient;
import com.example.feign.UserServiceFeignClient;
import com.example.model.Bookings;
import com.example.model.Orders;
import com.example.model.Train;
import com.example.model.Users;
import com.example.repository.BookingsRepository;
import com.razorpay.RazorpayException;


@Service
public class BookingsService {
	
	@Autowired
	private BookingsRepository bookingRepo;
	
	@Autowired
	private UserServiceFeignClient userServiceFeignClient;
	
	 @Autowired
	 private TrainServiceFeignClient trainServiceFeignClient;
	 
	 @Autowired
	 private PaymentServicefeignClient paymentServicefeignClient;
	
	// Method to generate a unique ticket ID
    private String generateUniqueTicketId() {
        Random random = new Random();
        String ticketId;
        do {
            char letter = (char) ('A' + random.nextInt(26)); // Generates a letter A-Z
            int number = random.nextInt(10000); // Generates a number from 0 to 9999
            ticketId = letter + String.format("%04d", number); // Formats the number to 4 digits
        } while (bookingRepo.existsByTicketId(ticketId)); // Check for uniqueness in the database
        return ticketId;
    }

    // Create a new booking
    public String save(Bookings booking) throws TrainNotFoundException, RazorpayException, UserNotFoundException {
    	
    	Train train = trainServiceFeignClient.getTrainById(booking.getTrainId()).getBody();
    	
    	Optional<Users> user = userServiceFeignClient.getById(booking.getUserId());
    	
    	
        if (train == null) {
            throw new TrainNotFoundException("Train not found for ID: " + booking.getTrainId());
        }
        
        if(user == null) {
        	throw new UserNotFoundException("User not found with ID:" + booking.getUserId());
        }
        
    	if (booking.getNoOfSeats() < 1 || booking.getNoOfSeats() > 4) {
            throw new InvalidTicketCountException("Number of tickets must be between 1 and 4");
        }
    	
    	Users foundUser = user.get();
    	String name = foundUser.getUsername();
    	String email = foundUser.getEmail();
    	
    	
    	booking.setFareamount(train.getFare() * booking.getNoOfSeats());
//    	booking.setTrainId(train.getTrainNumber());
    	booking.setBookingTime(LocalDateTime.now());
    	booking.setStatus("Booked");   	
    	Orders order = new Orders();
    	order.setName(name);
    	order.setEmail(email);
    	order.setAmount(booking.getFareamount());
    	
        booking.setTicketId(generateUniqueTicketId()); // Generate and set unique ticket ID
        Orders order1 = paymentServicefeignClient.createOrder(order).getBody();
        bookingRepo.save(booking);
        return "Booking Successful";
    }

	
//	public Optional<Bookings> findById(Long id){
//		return bookingRepo.findById(id).orElseThrow(() -> new BookingNotFoundException("Booking not found with id: " + id));
//	}
	
	public Optional<Bookings> findById(String id){
	    return Optional.of(bookingRepo.findById(id).orElseThrow(() -> new BookingNotFoundException("Booking with id: "+id+" Not found")));
	}

	
	public List<Bookings> findByUserId(Long id){
		List<Bookings> res = bookingRepo.findByUserId(id);
		if (res.isEmpty()) {
            throw new BookingNotFoundException("No bookings found for user id: " + id);
        }
		return res;
		//bookingRepo.findAllByUserId(id);
	}
	
	public String cancelBooking(String id) {
		 Bookings booking = bookingRepo.findById(id)
			        .orElseThrow(() -> new BookingNotFoundException("Booking with id: " + id + " Not found"));
		booking.setStatus("Cancelled");
		bookingRepo.save(booking);
		return "Tickets Cancelled Successfully";
	}
	
	public List<Bookings> getAllEntities(){
		return bookingRepo.findAll();
	}

}
