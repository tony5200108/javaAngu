package com.example.feign;

import java.util.Optional;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.model.Users;


@FeignClient(name = "User-Service", url = "http://localhost:9898/User")
public interface UserServiceFeignClient {
	
	@GetMapping("/retrieve/{id}")
    public Optional<Users> getById(@PathVariable int id);
}
