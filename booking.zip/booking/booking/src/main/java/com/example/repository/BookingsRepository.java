package com.example.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.model.Bookings;

public interface BookingsRepository extends JpaRepository<Bookings, String>{
	
	List<Bookings> findByUserId(Long userId);
	boolean existsByTicketId(String ticketId); // Method to check if ticket ID exists

}
