package com.example.model;

import java.time.LocalDateTime;
import java.time.LocalTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "booking")
public class Bookings {
	
	@Id
    private String ticketId;
 
    private int userId; // Reference to the User
    private String trainId; // Reference to the Train
    @Column(nullable = false,columnDefinition="INT DEFAULT 0")
    private int noOfSeats; // number of seats booked
    private double fareamount; //based on no of tickets and class.
    @Column(nullable = false)
    private LocalDateTime bookingTime;
    private String Status;
    
	public void setTicketId(String id) {
		// TODO Auto-generated method stub
		this.ticketId=id;
		
	}
	public String getTicketId() {
		
		return ticketId;
	}
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getTrainId() {
		return trainId;
	}
	public void setTrainId(String trainId) {
		this.trainId = trainId;
	}
	public int getNoOfSeats() {
		return noOfSeats;
	}
	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}
	public double getFareamount() {
		return fareamount;
	}
	public void setFareamount(double fareamount) {
		this.fareamount = fareamount;
	}
	public LocalDateTime getBookingTime() {
		return bookingTime;
	}
	public void setBookingTime(LocalDateTime bookingTime) {
		this.bookingTime = bookingTime;
	}
    
	

}
