package com.example.exception;

public class InvalidTicketCountException extends RuntimeException {
    public InvalidTicketCountException(String message) {
        super(message);
    }
}