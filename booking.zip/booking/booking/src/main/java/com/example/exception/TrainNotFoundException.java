package com.example.exception;

public class TrainNotFoundException extends Exception {
	public TrainNotFoundException(String message) {
        super(message);
    }
}
