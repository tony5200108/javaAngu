package com.example.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.exception.TrainNotFoundException;
import com.example.exception.UserNotFoundException;
import com.example.feign.TrainServiceFeignClient;
import com.example.model.Bookings;
import com.example.model.Train;
import com.example.service.BookingsService;
import com.razorpay.RazorpayException;


@RestController
@RequestMapping("/Bookings")
public class BookingsController {
	
	@Autowired
	private BookingsService bookingsService;
	
	@Autowired
	private TrainServiceFeignClient trainFeign;

	@PostMapping("/user/bookTicket")
	public String saveBook(@RequestBody Bookings book) throws TrainNotFoundException, RazorpayException, UserNotFoundException {
		bookingsService.save(book);
		return "Booked ticket with id : " + book.getTicketId()+" for the user with id :"+book.getUserId();
    }
	
	@GetMapping("/user/train/{trainid}")
		public ResponseEntity<Train> tDetails(@PathVariable String trainid) {
			return trainFeign.getTrainById(trainid);
		}
	
	@GetMapping("/user/getTicketDetails/{id}")
	public Optional<Bookings> getTicketDetails(@PathVariable String id){
		return bookingsService.findById(id);
	}
	
	
	@GetMapping("/user/getUserTickets/{userId}")
	public List<Bookings> getTicketsByUser(@PathVariable Long userId){
		List<Bookings> res = bookingsService.findByUserId(userId);
		return res;
		//return bookingsService.findByUserId(userId);
	}
	
//	@PutMapping("/updateTicket/{id}")
//	public Bookings updateOrder(@PathVariable("id") Long id,@RequestBody Bookings order ) {
//		Optional<Bookings> res = bookingsService.findById(id);
//		bookingsService.save(order);
//		return order;
//	}
		
	 @PutMapping("/user/cancel/{id}")
	 public String deleteOrder (@PathVariable String id) {
	  bookingsService.cancelBooking(id);
		return "Ticket with id : "+id+" cancelled Successfully Refund Initiated";
		}
	 
	 
	 @GetMapping("/test")
	 public String testApi() {
		 return "API Running Successfully";
	 }
	

}
