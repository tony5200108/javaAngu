package com.example.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.model.Train;

@FeignClient(name = "TRAIN-SERVICE" , url = "http://localhost:8777") 
public interface TrainServiceFeignClient {

	@GetMapping("/Trains/user/bytrainNumber/{trainNumber}")
    public ResponseEntity<Train> getTrainById(@PathVariable("trainNumber") String trainNumber);
}
