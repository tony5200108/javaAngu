package com.example.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.model.Orders;
import com.razorpay.RazorpayException;


@FeignClient(name = "Payment-Service", url = "http://localhost:8081/Payment")
public interface PaymentServicefeignClient {

	@PostMapping(value = "/user/createOrder", produces = "application/json")
	@ResponseBody
	public ResponseEntity<Orders> createOrder(@RequestBody Orders orders) throws RazorpayException;
}
