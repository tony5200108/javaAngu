package com.example.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.example.exception.BookingNotFoundException;
import com.example.exception.InvalidTicketCountException;
import com.example.exception.TrainNotFoundException;
import com.example.exception.UserNotFoundException;
import com.example.model.Bookings;
import com.example.repository.BookingsRepository;
import com.razorpay.RazorpayException;

public class BookingsServiceTest {

    @InjectMocks
    private BookingsService bookingsService;

    @Mock
    private BookingsRepository bookingsRepository;

    private Bookings booking;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        booking = new Bookings();
        booking.setUserId(1);
        booking.setTrainId("T12345"); // Changed to String
        booking.setNoOfSeats(2);
        booking.setFareamount(100.0);
    }

    @Test
    public void testSave_Success() throws TrainNotFoundException, RazorpayException, UserNotFoundException {
        // Mock the behavior of the repository
        when(bookingsRepository.existsByTicketId(anyString())).thenReturn(false);
        when(bookingsRepository.save(any(Bookings.class))).thenReturn(booking);

        // Call the save method
        String result = bookingsService.save(booking);

        // Assertions
        assertEquals("Booking Successful", result);
        assertNotNull(booking.getTicketId()); // Ensure ticketId is generated
        assertNotNull(booking.getBookingTime()); // Ensure bookingTime is set

        // Optionally check if the bookingTime is set to a value in the past
        assertTrue(booking.getBookingTime().isBefore(LocalDateTime.now().plusSeconds(1))); // Check if the time is reasonable
    }

    @Test
    public void testSave_InvalidTicketCount_ThrowsException() {
        booking.setNoOfSeats(5); // Invalid count

        Exception exception = assertThrows(InvalidTicketCountException.class, () -> {
            bookingsService.save(booking);
        });

        assertEquals("Number of tickets must be between 1 and 4", exception.getMessage());
        verify(bookingsRepository, never()).save(any(Bookings.class));
    }

    @Test
    public void testFindById_Success() {
        when(bookingsRepository.findById(anyString())).thenReturn(Optional.of(booking));

        Optional<Bookings> foundBooking = bookingsService.findById("A0001");

        assertTrue(foundBooking.isPresent());
        assertEquals(booking, foundBooking.get());
    }

    @Test
    public void testFindById_BookingNotFound_ThrowsException() {
        when(bookingsRepository.findById(anyString())).thenReturn(Optional.empty());

        Exception exception = assertThrows(BookingNotFoundException.class, () -> {
            bookingsService.findById("A0001");
        });

        assertEquals("Booking with id: A0001 Not found", exception.getMessage());
    }

    @Test
    public void testFindByUserId_Success() {
        when(bookingsRepository.findByUserId(1L)).thenReturn(Arrays.asList(booking));

        List<Bookings> bookingsList = bookingsService.findByUserId(1L);

        assertFalse(bookingsList.isEmpty());
        assertEquals(1, bookingsList.size());
    }

    @Test
    public void testFindByUserId_NoBookings_ThrowsException() {
        when(bookingsRepository.findByUserId(1L)).thenReturn(Arrays.asList());

        Exception exception = assertThrows(BookingNotFoundException.class, () -> {
            bookingsService.findByUserId(1L);
        });

        assertEquals("No bookings found for user id: 1", exception.getMessage());
    }

    @Test
    public void testCancelBooking_Success() {
        when(bookingsRepository.existsById("A0001")).thenReturn(true);

        String result = bookingsService.cancelBooking("A0001");

        assertEquals("Tickets Canceled Successfully", result);
        verify(bookingsRepository).deleteById("A0001");
    }

    @Test
    public void testCancelBooking_BookingNotFound_ThrowsException() {
        when(bookingsRepository.existsById("A0001")).thenReturn(false);

        Exception exception = assertThrows(BookingNotFoundException.class, () -> {
            bookingsService.cancelBooking("A0001");
        });

        assertEquals("Booking with id: A0001 Not found", exception.getMessage());
    }

    @Test
    public void testGetAllEntities() {
        when(bookingsRepository.findAll()).thenReturn(Arrays.asList(booking));

        List<Bookings> allBookings = bookingsService.getAllEntities();

        assertFalse(allBookings.isEmpty());
        assertEquals(1, allBookings.size());
    }
}
