package com.example.RazorPayment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RazorPaymentApplicationTests {

	@Test
	void contextLoads() {
	}

}
