package com.example.service;

import java.util.List;
import java.util.Map;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.example.model.Orders;
import com.example.repository.OrdersRepository;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;


import jakarta.annotation.PostConstruct;

@Service
public class OrderService {
	
	@Autowired
	private OrdersRepository ordersRepository;
	
	
	private RazorpayClient razorpayClient;
	
	    @Autowired
	    public OrderService(@Value("${razorpay.key.id}") String apiKey, @Value("${razorpay.key.secret}") String apiSecret) {
	        try {
	            this.razorpayClient = new RazorpayClient(apiKey, apiSecret);
	        } catch (Exception e) {
	            // Handle exception
	            e.printStackTrace();
	        }
	    }

	    public List<Orders> getAllOrders() {
	        return ordersRepository.findAll();
	    }
	    
	    public Orders createOrder(Orders orders) throws RazorpayException {
	        JSONObject options = new JSONObject();
	        options.put("amount", orders.getAmount() * 100); // amount in paise
	        options.put("currency", "INR");
	        options.put("receipt", orders.getEmail());

	        // Make sure razorpayClient is initialized
	        if (razorpayClient == null) {
	            throw new IllegalStateException("RazorpayClient is not initialized");
	        }

	        Order razorpayOrder = razorpayClient.orders.create(options);
	        
	        if (razorpayOrder != null) {
	            orders.setRazorpayOrderId(razorpayOrder.get("id"));
	            orders.setOrderStatus(razorpayOrder.get("status"));
	            
	        }
	        
	        return ordersRepository.save(orders);
	    }


	    public Orders updateStatus(Map<String, String> map) {
	        String razorpayId = map.get("razorpay_order_id");
	        Orders order = ordersRepository.findByRazorpayOrderId(razorpayId);
	        
	        if (order == null) {
	            throw new IllegalArgumentException("Order not found for Razorpay ID: " + razorpayId);
	        }

	        order.setOrderStatus("PAYMENT DONE");
	        return ordersRepository.save(order);
	    }
}