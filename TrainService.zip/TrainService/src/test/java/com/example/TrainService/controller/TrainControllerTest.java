package com.example.TrainService.controller;


import com.example.controller.TrainController;
import com.example.exception.StationNotFoundException;
import com.example.exception.TrainNumberShouldBeDigitException;
import com.example.model.Train;
import com.example.service.TrainService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class TrainControllerTest {

    @InjectMocks
    private TrainController trainController;

    @Mock
    private TrainService trainService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAllTrains() {
        Train train1 = new Train(); // Create a mock Train object
        Train train2 = new Train();
        List<Train> mockTrains = Arrays.asList(train1, train2);

        when(trainService.getAllTrains()).thenReturn(mockTrains);

        List<Train> trains = trainController.getAllTrains();

        assertEquals(2, trains.size());
        verify(trainService).getAllTrains();
    }

    @Test
    void testGetTrainById_Success() {
        Train mockTrain = new Train();
        String trainNumber = "123";

        when(trainService.getTrainById(trainNumber)).thenReturn(Optional.of(mockTrain));

        ResponseEntity<Train> response = trainController.getTrainById(trainNumber);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(mockTrain, response.getBody());
    }

    @Test
    void testGetTrainById_NotFound() {
        String trainNumber = "999";

        when(trainService.getTrainById(trainNumber)).thenReturn(Optional.empty());

        ResponseEntity<Train> response = trainController.getTrainById(trainNumber);

        assertEquals(404, response.getStatusCodeValue());
    }

    @Test
    void testFindTrains_Success() throws StationNotFoundException {
        Train mockTrain = new Train();
        List<Train> mockTrains = Arrays.asList(mockTrain);
        String source = "StationA";
        String destination = "StationB";

        when(trainService.findTrainsBetween(source, destination)).thenReturn(mockTrains);

        List<Train> trains = trainController.findTrains(source, destination);

        assertEquals(1, trains.size());
        verify(trainService).findTrainsBetween(source, destination);
    }

    @Test
    void testCreateTrain_Success() throws TrainNumberShouldBeDigitException {
        Train mockTrain = new Train();
        when(trainService.createTrain(any(Train.class))).thenReturn(mockTrain);

        Train createdTrain = trainController.createTrain(mockTrain);

        assertEquals(mockTrain, createdTrain);
        verify(trainService).createTrain(mockTrain);
    }

    @Test
    void testUpdateTrain_Success() {
        Train mockTrain = new Train();
        String trainNumber = "123";

        when(trainService.updateTrain(eq(trainNumber), any(Train.class))).thenReturn(mockTrain);

        Train updatedTrain = trainController.updateTrain(trainNumber, mockTrain);

        assertEquals(mockTrain, updatedTrain);
        verify(trainService).updateTrain(trainNumber, mockTrain);
    }

    @Test
    void testDeleteTrain_Success() {
        String trainNumber = "123";
        String responseMessage = "Train deleted successfully";

        when(trainService.deleteTrain(trainNumber)).thenReturn(responseMessage);

        ResponseEntity<String> response = trainController.deleteTrain(trainNumber);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(responseMessage, response.getBody());
        verify(trainService).deleteTrain(trainNumber);
    }
}
