package com.example.TrainService.service;



import com.example.exception.StationNotFoundException;
import com.example.exception.TrainAlreadyExistsException;
import com.example.exception.TrainNotFoundException;
import com.example.exception.TrainNumberShouldBeDigitException;
import com.example.model.Train;
import com.example.repository.TrainRepository;
import com.example.service.TrainService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class TrainServiceTest {

    @InjectMocks
    private TrainService trainService;

    @Mock
    private TrainRepository trainRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAllTrains() {
        Train train1 = new Train(); // Create a mock Train object
        Train train2 = new Train();
        List<Train> mockTrains = Arrays.asList(train1, train2);

        when(trainRepository.findAll()).thenReturn(mockTrains);

        List<Train> trains = trainService.getAllTrains();

        assertEquals(2, trains.size());
        verify(trainRepository).findAll();
    }

    @Test
    void testGetTrainById_Success() {
        Train mockTrain = new Train();
        String trainNumber = "123";

        when(trainRepository.findById(trainNumber)).thenReturn(Optional.of(mockTrain));

        Optional<Train> train = trainService.getTrainById(trainNumber);

        assertTrue(train.isPresent());
        assertEquals(mockTrain, train.get());
    }

    @Test
    void testGetTrainById_NotFound() {
        String trainNumber = "999";

        when(trainRepository.findById(trainNumber)).thenReturn(Optional.empty());

        Exception exception = assertThrows(TrainNotFoundException.class, () -> {
            trainService.getTrainById(trainNumber);
        });

        assertEquals("Train not found with train number 999", exception.getMessage());
    }

    @Test
    void testFindTrainsBetween_Success() throws StationNotFoundException {
        Train mockTrain = new Train();
        List<Train> mockTrains = Arrays.asList(mockTrain);
        String source = "StationA";
        String destination = "StationB";

        when(trainRepository.findBySourceAndDestination(source, destination)).thenReturn(mockTrains);

        List<Train> trains = trainService.findTrainsBetween(source, destination);

        assertEquals(1, trains.size());
        verify(trainRepository).findBySourceAndDestination(source, destination);
    }

    @Test
    void testFindTrainsBetween_NotFound() {
        String source = "StationA";
        String destination = "StationB";

        when(trainRepository.findBySourceAndDestination(source, destination)).thenReturn(Arrays.asList());

        Exception exception = assertThrows(StationNotFoundException.class, () -> {
            trainService.findTrainsBetween(source, destination);
        });

        assertEquals("No trains found between StationA and StationB", exception.getMessage());
    }

    @Test
    void testCreateTrain_Success() throws TrainNumberShouldBeDigitException {
        Train mockTrain = new Train();
        mockTrain.setTrainNumber("12345"); // Set a valid train number

        when(trainRepository.existsByTrainNumber(mockTrain.getTrainNumber())).thenReturn(false);
        when(trainRepository.save(any(Train.class))).thenReturn(mockTrain);

        Train createdTrain = trainService.createTrain(mockTrain);

        assertEquals(mockTrain, createdTrain);
        verify(trainRepository).save(mockTrain);
    }

    @Test
    void testCreateTrain_InvalidTrainNumber() {
        Train mockTrain = new Train();
        mockTrain.setTrainNumber("123"); // Invalid train number

        Exception exception = assertThrows(TrainNumberShouldBeDigitException.class, () -> {
            trainService.createTrain(mockTrain);
        });

        assertEquals("Train number must be a numeric value of fixed length (5 digits): 123", exception.getMessage());
    }

    @Test
    void testCreateTrain_TrainAlreadyExists() throws TrainNumberShouldBeDigitException {
        Train mockTrain = new Train();
        mockTrain.setTrainNumber("12345"); // Set a valid train number

        when(trainRepository.existsByTrainNumber(mockTrain.getTrainNumber())).thenReturn(true);

        Exception exception = assertThrows(TrainAlreadyExistsException.class, () -> {
            trainService.createTrain(mockTrain);
        });

        assertEquals("Train number already exists: 12345", exception.getMessage());
    }

    @Test
    void testUpdateTrain_Success() {
        Train existingTrain = new Train();
        existingTrain.setTrainNumber("123");
        existingTrain.setSource("OldSource");

        Train updatedDetails = new Train();
        updatedDetails.setSource("NewSource");

        when(trainRepository.findById(existingTrain.getTrainNumber())).thenReturn(Optional.of(existingTrain));
        when(trainRepository.save(existingTrain)).thenReturn(existingTrain);

        Train updatedTrain = trainService.updateTrain(existingTrain.getTrainNumber(), updatedDetails);

        assertEquals("NewSource", updatedTrain.getSource());
        verify(trainRepository).save(existingTrain);
    }

    @Test
    void testUpdateTrain_NotFound() {
        String trainNumber = "999";
        Train trainDetails = new Train();

        when(trainRepository.findById(trainNumber)).thenReturn(Optional.empty());

        Exception exception = assertThrows(TrainNotFoundException.class, () -> {
            trainService.updateTrain(trainNumber, trainDetails);
        });

        assertEquals("Train not found with train number 999", exception.getMessage());
    }

    @Test
    void testDeleteTrain_Success() {
        Train existingTrain = new Train();
        existingTrain.setTrainNumber("123");

        when(trainRepository.findById(existingTrain.getTrainNumber())).thenReturn(Optional.of(existingTrain));

        String responseMessage = trainService.deleteTrain(existingTrain.getTrainNumber());

        assertEquals("Train deleted successfully", responseMessage);
        verify(trainRepository).delete(existingTrain);
    }

    @Test
    void testDeleteTrain_NotFound() {
        String trainNumber = "999";

        when(trainRepository.findById(trainNumber)).thenReturn(Optional.empty());

        Exception exception = assertThrows(TrainNotFoundException.class, () -> {
            trainService.deleteTrain(trainNumber);
        });

        assertEquals("Train not found with train number 999", exception.getMessage());
    }
}
