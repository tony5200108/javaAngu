package com.example.exception;

public class TrainNumberShouldBeDigitException extends Exception {
	public TrainNumberShouldBeDigitException (String message ) {
		super(message);
	}

}
