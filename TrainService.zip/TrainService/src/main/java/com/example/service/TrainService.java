package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.exception.StationNotFoundException;
import com.example.exception.TrainAlreadyExistsException;
import com.example.exception.TrainNotFoundException;
import com.example.exception.TrainNumberShouldBeDigitException;
import com.example.model.Train;
import com.example.repository.TrainRepository;

import java.util.List;
import java.util.Optional;

@Service
public class TrainService {
    @Autowired
    private TrainRepository trainRepository;

    public List<Train> getAllTrains() {
        return trainRepository.findAll();
    }

    public Optional<Train> getTrainById(String trainNumber) {
        // Handle the case where the train is not found
        return trainRepository.findById(trainNumber)
                .or(() -> {
                    throw new TrainNotFoundException("Train not found with train number " + trainNumber);
                });
    }

    public List<Train> findTrainsBetween(String source, String destination) throws StationNotFoundException {
        List<Train> trains = trainRepository.findBySourceAndDestination(source, destination);
        if (trains.isEmpty()) {
            throw new StationNotFoundException("No trains found between " + source + " and " + destination);
        }
        return trains;
    }


    public Train createTrain(Train train) throws TrainNumberShouldBeDigitException {
        // Validate that the train number is numeric and has a fixed length
        if (!isTrainNumberValid(train.getTrainNumber())) {
            throw new TrainNumberShouldBeDigitException("Train number must be a numeric value of fixed length (5 digits): " + train.getTrainNumber());
        }
        
        if (trainRepository.existsByTrainNumber(train.getTrainNumber())) {
            throw new TrainAlreadyExistsException("Train number already exists: " + train.getTrainNumber());
        }
        return trainRepository.save(train);
    }

    // Helper method to check if train number is valid
    private boolean isTrainNumberValid(String trainNumber) {
        return trainNumber != null && trainNumber.matches("\\d{5}");
    }


    public Train updateTrain(String trainNumber, Train trainDetails) {
        Train train = trainRepository.findById(trainNumber)
                .orElseThrow(() -> new TrainNotFoundException("Train not found with train number " + trainNumber));
        
        // Update fields
        train.setSource(trainDetails.getSource());
        train.setDestination(trainDetails.getDestination());
        train.setDepartureTime(trainDetails.getDepartureTime());
        train.setArrivalTime(trainDetails.getArrivalTime());
        train.setFare(trainDetails.getFare());
        train.setTotalSeats(trainDetails.getTotalSeats());
        return trainRepository.save(train);
    }

    public String deleteTrain(String trainNumber) {
        Train train = trainRepository.findById(trainNumber)
                .orElseThrow(() -> new TrainNotFoundException("Train not found with train number " + trainNumber));
        trainRepository.delete(train);
        return "Train deleted successfully";
    }
}
