package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.model.Train;
import com.example.service.TrainService;
import com.example.exception.StationNotFoundException;
import com.example.exception.TrainNotFoundException;
import com.example.exception.TrainNumberShouldBeDigitException;

import java.util.List;

@RestController
@RequestMapping("/Trains")
public class TrainController {
    @Autowired
    private TrainService trainService;

    @GetMapping("/user/getAll")
    public List<Train> getAllTrains() {
        return trainService.getAllTrains();
    }

    @GetMapping("/user/bytrainNumber/{trainNumber}")
    public ResponseEntity<Train> getTrainById(@PathVariable("trainNumber") String trainNumber) {
        return trainService.getTrainById(trainNumber)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/user/searchByStation")
    public List<Train> findTrains(@RequestParam String source, @RequestParam String destination) throws StationNotFoundException {
        return trainService.findTrainsBetween(source, destination);
    }

    @PostMapping("/addDetails")
    public Train createTrain(@RequestBody Train train) throws TrainNumberShouldBeDigitException {
        return trainService.createTrain(train);
    }

    @PutMapping("/update/{trainNumber}")
    public Train updateTrain(@PathVariable String trainNumber, @RequestBody Train trainDetails) {
        return trainService.updateTrain(trainNumber, trainDetails);
    }

    @DeleteMapping("/delete/{trainNumber}")
    public ResponseEntity<String> deleteTrain(@PathVariable String trainNumber) {
        String responseMessage = trainService.deleteTrain(trainNumber);
        return ResponseEntity.ok(responseMessage);
    }

}
