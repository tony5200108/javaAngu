package com.example.apiGateWay.filter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import com.example.apiGateWay.util.JwtUtil;

import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferFactory;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;


import org.springframework.http.HttpMethod;

@Component
public class JwtAuthenticationFilter extends AbstractGatewayFilterFactory<JwtAuthenticationFilter.Config> {

	@Autowired
	private JwtUtil jwtUtil;

	@Autowired
	private RouteValidator validator;

	public JwtAuthenticationFilter() {
		super(Config.class);
	}

	
	@Override
	public GatewayFilter apply(Config config) {
	    return (exchange, chain) -> {
	        if (validator.isSecured.test(exchange.getRequest())) {
	            if (!exchange.getRequest().getHeaders().containsKey(HttpHeaders.AUTHORIZATION)) {
	                return handleUnauthorized(exchange, "Missing Authorization header");
	            }

	            String authHeader = exchange.getRequest().getHeaders().get(HttpHeaders.AUTHORIZATION).get(0);
	            HttpMethod method = exchange.getRequest().getMethod();
	            
	            if (authHeader != null && authHeader.startsWith("Bearer ")) {
	                authHeader = authHeader.substring(7);
	            }

	            try {
	                jwtUtil.validateToken(authHeader);
	                String role = jwtUtil.extractRole(authHeader);
	                String path = exchange.getRequest().getURI().getPath();

	                System.out.println("Role: " + role + ", Path: " + path + ", Method: " + method);
	                 
	                if (!checkRoleAccess(role, path, method)) {
	                    return handleUnauthorized(exchange, "You don't have permissions to access this endpoint");
	                }
	            } catch (Exception e) {
	                return handleUnauthorized(exchange, "Unauthorized access to the application"); //when jwt token is invalid
	            }
	        }
	        return chain.filter(exchange);
	    };
	}

	private Mono<Void> handleUnauthorized(ServerWebExchange exchange, String message) {
	    exchange.getResponse().setStatusCode(HttpStatus.FORBIDDEN);
	    exchange.getResponse().getHeaders().setContentType(MediaType.APPLICATION_JSON);
	    String responseBody = "{\"error\": \"" + message + "\"}";

	    DataBufferFactory dataBufferFactory = exchange.getResponse().bufferFactory();
	    DataBuffer dataBuffer = dataBufferFactory.wrap(responseBody.getBytes(StandardCharsets.UTF_8));

	    return exchange.getResponse().writeWith(Mono.just(dataBuffer));
	}

	/**
	 * checkRoleAccess method checks if a role has access to a specific path based
	 * on predefined rules.
	 * 
	 * @param role Role extracted from the JWT token
	 * @param path Requested path from the URI
	 * @return true if the role has access to the path, false otherwise
	 */
	private boolean checkRoleAccess(String role, String path, HttpMethod method) {
	    if ("Admin".equals(role)) { // Use equals method for comparison
	        return true; // Admin can access everything
	    } else if ("USER".equals(role)) {
	        return (path.startsWith("/User/user") || path.startsWith("/Trains/user")) || path.startsWith("/Bookings/user")
	        		|| path.startsWith("/Payment/user") ||path.startsWith("/User/retrieve") 
	        		&& (method.equals(HttpMethod.GET) || method.equals(HttpMethod.DELETE) || method.equals(HttpMethod.POST) 
	        				|| method.equals(HttpMethod.PUT));
	    }
	    return false; // Default: deny access
	}


	/**
	 * Config is a static inner class for configuring the AuthenticationFilter. It
	 * is currently empty as there are no specific configurations needed for this
	 * filter.
	 */
	public static class Config {

	}
}
