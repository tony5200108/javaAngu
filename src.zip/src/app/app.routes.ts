import { Routes } from '@angular/router';
import { AddTrainComponent } from './admin/add-train/add-train.component';
import { DeleteTrainsComponent } from './admin/delete-trains/delete-trains.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './login/register.component';
import { DashPageComponent } from './pages/dash-page.component';
import { HomeComponent } from './pages/home.component';
import { ProfileComponent } from './profile/profile.component';

import { TrainSearchComponent } from './trains/train-search/train-search.component';
import { BookingCardComponent } from './profile/booking-card/booking-card.component';
import { TransactionComponent } from './profile/transactions/transactions.component';
import { AllTrainsComponent } from './trains/all-trains/all-trains.component';


export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  {
    path: 'dashboard',
    component: DashPageComponent,
    children: [
      { path: 'add-trains', component: AddTrainComponent },
      { path: 'delete-trains', component: DeleteTrainsComponent },
      { path: 'profile', component: ProfileComponent },

      { path: 'train-search', component: TrainSearchComponent },
      { path: 'booking-card', component: BookingCardComponent },
      {path: 'transactions', component: TransactionComponent},
      {path: 'all-trains', component: AllTrainsComponent},
    ],
  },
  { path: '**', redirectTo: '', pathMatch: 'full' },
];
