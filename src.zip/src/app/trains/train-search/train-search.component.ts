import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { TrainResultsComponent } from '../train-results/train-results.component';

@Component({
  selector: 'app-train-search',
  standalone: true,
  imports: [CommonModule, FormsModule, TrainResultsComponent, HttpClientModule],
  templateUrl: './train-search.component.html',
  styleUrls: ['./train-search.component.css'],
})
export class TrainSearchComponent {
  source: string = '';
  destination: string = '';
  showResults: boolean = false;

  handleSearch(): void {
    console.log(
      'Search button clicked. Source:',
      this.source,
      'Destination:',
      this.destination
    );

    if (this.source && this.destination) {
      this.showResults = true;
    } else {
      console.warn('Source or destination is missing.');
      alert('Please enter both source and destination.');
    }
  }
}
