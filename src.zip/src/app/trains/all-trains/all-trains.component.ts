import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-trains',
  standalone: true,
  imports: [ CommonModule],
  // Add necessary modules for the standalone component
  templateUrl: './all-trains.component.html',
  styleUrls: ['./all-trains.component.scss'],  // Fixed typo here (styleUrl -> styleUrls)
})
export class AllTrainsComponent implements OnInit {
  
  // Define any properties needed
  trains: any[] = [];
  error: string | null = null;
  loading: boolean = true;

  constructor() {
    // Optionally, initialize any properties or services
  }

  ngOnInit(): void {
    // Initialization logic like fetching data can go here in the future
    console.log('AllTrainsComponent initialized');
  }

}
