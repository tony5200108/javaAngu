import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders, HttpClientModule } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';

import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

declare global {
  interface Window {
    Razorpay: any;
  }
}

@Component({
  selector: 'app-booking-card',
  templateUrl: './booking-card.component.html',
  styleUrls: ['./booking-card.component.scss'],
  standalone: true,
  imports: [FormsModule, HttpClientModule], // Import FormsModule here
})
export class BookingCardComponent implements OnInit {
  train: any;
  numberOfSeats: number = 1;
  token: string | null = localStorage.getItem('token');
  tokenData: any = this.parseJwt(this.token);
  userId: string = this.tokenData.id;
  userEmail: string = this.tokenData.email;

  constructor(private http: HttpClient, private route: ActivatedRoute) {}

  ngOnInit() {
    this.train = history.state.train;
    this.loadRazorpayScript();
  }

  parseJwt(token: string | null): any {
    if (!token) return {};
    const base64Url = token.split('.')[1];
    return JSON.parse(atob(base64Url));
  }

  loadRazorpayScript() {
    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.async = true;
    document.body.appendChild(script);
  }

  handlePayment() {
    if (this.numberOfSeats < 1 || this.numberOfSeats > 4) {
      alert('No of seats must be between 1 and 4');
      return;
    }

    const orderData = {
      name: this.tokenData.sub,
      email: this.userEmail,
      amount: this.train.fare * this.numberOfSeats,
      userid: this.userId,
    };

    const headers = new HttpHeaders({
      Authorization: `Bearer ${this.token}`,
      'Content-Type': 'application/json',
    });

    this.http.post('http://localhost:8080/Payment/user/createOrder', orderData, { headers }).subscribe(
      (response: any) => {
        const options = {
          key: 'rzp_test_GGqgmFBLIg33LX',
          amount: response.amount * 100,
          currency: 'INR',
          name: 'Train Booking',
          description: `Booking for ${this.train.trainNumber}`,
          order_id: response.razorpayOrderId,
          handler: (paymentResponse: any) => {
            alert('Payment Successful!');
          },
        };

        const rzp1 = new window.Razorpay(options);
        rzp1.open();
      },
      (error) => {
        console.error('Error during payment process:', error);
      }
    );
  }
}
