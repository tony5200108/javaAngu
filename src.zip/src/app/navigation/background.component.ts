import { Component } from '@angular/core';

@Component({
  selector: 'app-background',
  standalone: true,
  template: '',
  styleUrls: ['./background.component.scss'],
})
export class BackgroundComponent {}
