import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { NavbarComponent } from '../dashboard/navbar/navbar.component';
import { GreetingComponent } from '../greeting/greeting.component';

@Component({
  selector: 'app-dash-page',
  standalone: true,
  template: `
    <div class="app">
      <app-navbar></app-navbar>
      <!-- Navbar for navigation -->

      <div class="dashboard-container">
        
        <app-greeting></app-greeting>
        <!-- Greeting component added here -->
        
        <router-outlet></router-outlet>
        <!-- This will render routed components like AddTrainComponent, DeleteTrainsComponent, and ProfileComponent -->
      </div>
    </div>
  `,
  styleUrls: ['./dash-page.component.scss'],
  imports: [RouterOutlet, NavbarComponent, GreetingComponent],
})
export class DashPageComponent {
  constructor() {
    console.log('DashPageComponent initialized');
  }

  ngOnInit() {
    console.log('DashPageComponent loaded on route:', window.location.pathname);
  }
}
